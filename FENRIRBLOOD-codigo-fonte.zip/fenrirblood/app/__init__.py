"""FENRIRBLOOD core."""
