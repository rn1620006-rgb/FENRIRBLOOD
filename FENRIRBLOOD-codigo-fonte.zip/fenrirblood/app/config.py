import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")
DB_PATH = Path(os.getenv("FENRIR_DB_PATH", str(ROOT / "data" / "fenrirblood.sqlite3"))).resolve()
SECURE_COOKIES = os.getenv("FENRIR_SECURE_COOKIES", "false").lower() == "true"
PUBLIC_URL = os.getenv("FENRIR_PUBLIC_URL", "http://127.0.0.1:8000").rstrip("/")
ALLOWED_ORIGINS = set(filter(None, (x.strip().rstrip("/") for x in os.getenv("FENRIR_ALLOWED_ORIGINS", "").split(","))))
SESSION_DAYS = max(1, min(int(os.getenv("FENRIR_SESSION_DAYS", "7")), 30))
